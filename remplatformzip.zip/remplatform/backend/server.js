const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');
const app = express();
const PORT = process.env.PORT || 5000;
const SECRET = process.env.JWT_SECRET || 'rem_secret';

app.use(express.json());
// PostgreSQL setup
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://user:password@localhost:5432/remdb',
// Auth middleware
function auth(role) {
  return (req, res, next) => {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'No token' });
  try {
  const decoded = jwt.verify(header.replace('Bearer ', ''), SECRET);
  if (role && decoded.role !== role) return res.status(403).json({ error: 'Forbidden' });
  req.user = decoded;
      next();
    } catch {
      res.status(401).json({ error: 'Invalid token' });
    }
  };
}
app.get('/', (req, res) => {
  res.send('REM Backend API is running');
});
// Matcher endpoint (secured)
app.post('/match', auth(), async (req, res) => {
  const { features, location } = req.body;
  try {
    const result = await pool.query('SELECT * FROM properties WHERE location ILIKE $1', [`%${location}%`]);
    const required = features.map(f => f.trim().toLowerCase()).filter(f => f);
    const matches = result.rows.filter(p => {
      const propFeatures = p.features.map(f => f.toLowerCase());
      const matchCount = required.filter(f => propFeatures.includes(f)).length;
      const percent = required.length ? (matchCount / required.length) * 100 : 0;
      return percent >= 95;
    });
    res.json(matches);
  } catch (err) {
    res.status(500).json({ error: 'Matcher error' });
  }
});

// Seller verification endpoint (secured)
app.post('/verify', auth(), async (req, res) => {
  const { seller } = req.body;
  try {
    const result = await pool.query('SELECT verified FROM properties WHERE seller = $1 LIMIT 1', [seller]);
    res.json({ seller, verified: result.rows[0]?.verified || false });
  } catch {
    res.json({ seller, verified: false });
  }
});

// Outreach endpoint (secured)
app.post('/outreach', auth(), async (req, res) => {
  const { propertyId, method } = req.body;
  try {
  const result = await pool.query('SELECT contact FROM properties WHERE id = $1', [propertyId]);
  if (!result.rows.length) return res.status(404).json({ error: 'Property not found' });
  // Simulate sending email/WhatsApp (integrate with real API in production)
    res.json({ status: 'sent', method, contact: result.rows[0].contact });
  } catch {
    res.status(500).json({ error: 'Outreach error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
const express = require('express');
const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());

app.get('/', (req, res) => {
  res.send('REM Backend API is running');
});


// Simulated property data
const properties = [
  { id: 1, features: ['pool', 'garden', '3 bedrooms'], location: 'Sandton', seller: 'John Doe', verified: false, contact: 'john@example.com' },
  { id: 2, features: ['garage', '2 bedrooms'], location: 'Randburg', seller: 'Jane Smith', verified: false, contact: 'jane@example.com' },
  { id: 3, features: ['pool', 'garden', '3 bedrooms', 'garage'], location: 'Sandton', seller: 'Verified Seller', verified: true, contact: 'verified@example.com' },
];

// Matcher endpoint
app.post('/match', (req, res) => {
  const { features, location } = req.body;
  const required = features.map(f => f.trim().toLowerCase()).filter(f => f);
  const matches = properties.filter(p => {
    const propFeatures = p.features.map(f => f.toLowerCase());
    const matchCount = required.filter(f => propFeatures.includes(f)).length;
    const percent = required.length ? (matchCount / required.length) * 100 : 0;
    return percent >= 95 && p.location.toLowerCase().includes(location.toLowerCase());
  });
  res.json(matches);
});

// Seller verification endpoint
app.post('/verify', (req, res) => {
  const { seller } = req.body;
  // Simulate verification (in real app, check public records, etc.)
  const found = properties.find(p => p.seller === seller);
  res.json({ seller, verified: found ? found.verified : false });
});

// Outreach endpoint
app.post('/outreach', (req, res) => {
  const { propertyId, method } = req.body;
  const property = properties.find(p => p.id === propertyId);
  if (!property) return res.status(404).json({ error: 'Property not found' });
  // Simulate sending email/WhatsApp (in real app, integrate with email/WhatsApp API)
  res.json({ status: 'sent', method, contact: property.contact });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
