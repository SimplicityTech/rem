const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const app = express();
const PORT = process.env.PORT || 5000;
const SECRET = process.env.JWT_SECRET || 'rem_secret';

app.use(express.json());

// Simulated user DB
const users = [
  { id: 1, name: 'Admin', email: 'admin@homemarket.africa', password_hash: bcrypt.hashSync('admin123', 10), role: 'admin' },
];

// Auth: Register
app.post('/register', (req, res) => {
  const { name, email, password } = req.body;
  if (users.find(u => u.email === email)) return res.status(400).json({ error: 'Email exists' });
  const password_hash = bcrypt.hashSync(password, 10);
  const user = { id: users.length + 1, name, email, password_hash, role: 'buyer' };
  users.push(user);
  res.json({ message: 'Registered', user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

// Auth: Login
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, role: user.role }, SECRET, { expiresIn: '1h' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

// Auth middleware
function auth(role) {
  return (req, res, next) => {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ error: 'No token' });
    try {
      const decoded = jwt.verify(header.replace('Bearer ', ''), SECRET);
      if (role && decoded.role !== role) return res.status(403).json({ error: 'Forbidden' });
      req.user = decoded;
      next();
    } catch {
      res.status(401).json({ error: 'Invalid token' });
    }
  };
}

// Admin dashboard route
app.get('/admin/dashboard', auth('admin'), (req, res) => {
  res.json({ users, message: 'Admin dashboard' });
});

// ...existing code...

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
