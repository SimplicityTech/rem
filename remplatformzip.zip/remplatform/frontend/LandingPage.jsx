import React from 'react';
import './LandingPage.css';
import logo from './rem_logo.png'; // Place your logo image in frontend/rem_logo.png

function LandingPage({ onStart }) {
  return (
    <div className="landing-container">
      {/* Hero Section */}
      <header className="landing-header">
        <img src={logo} alt="REM Logo" className="landing-logo" />
        <h1 className="landing-title">Dreaming for Dreamers</h1>
        <p className="landing-subtitle">
          Freedom to dream with no limitations
        </p>
        <p className="landing-tagline">
          Welcome to REM (Real Estate Market) — where AI connects buyers and sellers to make dream homes a reality.
        </p>
        <button className="landing-btn" onClick={onStart}>
          Start Your Wishlist
        </button>
      </header>

      {/* How It Works Section */}
      <section className="landing-how">
        <h2 className="section-title">How REM Works</h2>
        <div className="steps-container">
          <div className="step">
            <h3>Create Your Wishlist</h3>
            <p>Tell us what your dream property looks like — from location to features.</p>
          </div>
          <div className="step">
            <h3>AI Finds Matches</h3>
            <p>Our AI scans the market and finds properties with a 95%+ match to your wishlist.</p>
          </div>
          <div className="step">
            <h3>Connect Securely</h3>
            <p>We verify sellers and connect you safely via email or WhatsApp.</p>
          </div>
        </div>
      </section>

      {/* Vision / Core Value Section */}
      <section className="landing-vision">
        <h2 className="section-title">Our Vision</h2>
        <p>
          At REM, we believe in empowering dreamers. Whether it’s your first home, an investment, or a forever space, 
          our mission is to give you the freedom to dream without limits — and the tools to make those dreams real.
        </p>
      </section>

      {/* Footer */}
      <footer className="landing-footer">
        &copy; {new Date().getFullYear()} Home Market Pty Ltd. All rights reserved.
      </footer>
    </div>
  );
}

export default LandingPage;