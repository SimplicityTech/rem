import React, { useState } from 'react';
import logo from './rem_logo.png';
import './WishlistForm.css';

function WishlistForm({ onSubmit }) {
  const [features, setFeatures] = useState('');
  const [location, setLocation] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ features: features.split(','), location });
  };

  return (
    <div className="wishlist-container">
      <img src={logo} alt="REM Logo" className="wishlist-logo" />
      <h2 className="wishlist-title">Create Your Wishlist</h2>
      <form className="wishlist-form" onSubmit={handleSubmit}>
        <label className="wishlist-label">
          Features (comma separated):
          <input
            type="text"
            value={features}
            onChange={e => setFeatures(e.target.value)}
            placeholder="e.g. pool, garden, 3 bedrooms"
            className="wishlist-input"
            required
          />
        </label>
        <label className="wishlist-label">
          Ideal Location:
          <input
            type="text"
            value={location}
            onChange={e => setLocation(e.target.value)}
            placeholder="e.g. Sandton, Johannesburg"
            className="wishlist-input"
            required
          />
        </label>
        <button type="submit" className="wishlist-btn">Find Matches</button>
      </form>
    </div>
  );
}

export default WishlistForm;
