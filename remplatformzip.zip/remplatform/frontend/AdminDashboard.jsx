import React, { useState } from 'react';
import logo from './rem_logo.png';
import './AdminDashboard.css';

function AdminDashboard({ token }) {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');

  React.useEffect(() => {
    if (!token) return;
    fetch('http://localhost:5000/admin/dashboard', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (data.users) setUsers(data.users);
        else setError(data.error || 'Unknown error');
      })
      .catch(() => setError('Failed to load dashboard'));
  }, [token]);

  if (!token) return <div className="admin-message">Please log in as admin.</div>;
  if (error) return <div className="admin-message">Error: {error}</div>;

  return (
    <div className="admin-container">
      <img src={logo} alt="REM Logo" className="admin-logo" />
      <h2 className="admin-title">Admin Dashboard</h2>
      <ul className="admin-list">
        {users.map(u => (
          <li key={u.id} className="admin-list-item">
            <span className="admin-user-name">{u.name}</span> <span className="admin-user-email">({u.email})</span> - <span className="admin-user-role">{u.role}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AdminDashboard;
