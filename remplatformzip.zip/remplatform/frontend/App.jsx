
import React, { useState } from 'react';
import WishlistForm from './WishlistForm';
import AdminDashboard from './AdminDashboard';
import LandingPage from './LandingPage';

function App() {
  const [wishlist, setWishlist] = useState(null);
  const [matches, setMatches] = useState([]);
  const [token, setToken] = useState('');
  const [user, setUser] = useState(null);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showLanding, setShowLanding] = useState(true);
  // Auth: Register
  const register = async (name, email, password) => {
    try {
      const res = await fetch('http://localhost:5000/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });
      const data = await res.json();
      if (data.user) alert('Registered! Please log in.');
      else alert(data.error || 'Registration failed');
    } catch {
      alert('Registration error');
    }
  };

  // Auth: Login
  const login = async (email, password) => {
    try {
      const res = await fetch('http://localhost:5000/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (data.token) {
        setToken(data.token);
        setUser(data.user);
        setShowAdmin(data.user.role === 'admin');
      } else {
        alert(data.error || 'Login failed');
      }
    } catch {
      alert('Login error');
    }
  };


  // Backend matcher API call
  const findMatches = async (wishlistData) => {
    setWishlist(wishlistData);
    try {
      const res = await fetch('http://localhost:5000/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(wishlistData)
      });
      const data = await res.json();
      setMatches(data);
    } catch (err) {
      setMatches([]);
    }
  };

  // Seller verification
  const verifySeller = async (seller) => {
    try {
      const res = await fetch('http://localhost:5000/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ seller })
      });
      const data = await res.json();
      return data.verified;
    } catch {
      return false;
    }
  };

  // Outreach (contact seller)
  const contactSeller = async (propertyId, method) => {
    try {
      const res = await fetch('http://localhost:5000/outreach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, method })
      });
      const data = await res.json();
      alert(`Contact ${method} sent to ${data.contact}`);
    } catch {
      alert('Failed to contact seller');
    }
  };

  return (
    <div className="App">
      {showLanding ? (
        <LandingPage onStart={() => setShowLanding(false)} />
      ) : (
        <>
          {/* Auth UI */}
          {!token && (
            <div>
              <h2>Login</h2>
              <LoginForm onLogin={login} />
              <h2>Register</h2>
              <RegisterForm onRegister={register} />
            </div>
          )}

          {/* Admin Dashboard */}
          {showAdmin && token && (
            <AdminDashboard token={token} />
          )}

          {/* Buyer UI */}
          {token && !showAdmin && (
            <>
              <WishlistForm onSubmit={findMatches} />
              {wishlist && (
                <div>
                  <h2>Matches for your Wishlist</h2>
                  {matches.length === 0 ? (
                    <p>No properties found matching your criteria.</p>
                  ) : (
                    <ul>
                      {matches.map(p => (
                        <li key={p.id}>
                          <strong>Features:</strong> {p.features.join(', ')}<br />
                          <strong>Location:</strong> {p.location}<br />
                          <strong>Seller:</strong> {p.seller}
                          <br />
                          <SellerVerification seller={p.seller} />
                          <button onClick={() => contactSeller(p.id, 'email')}>Contact by Email</button>
                          <button onClick={() => contactSeller(p.id, 'whatsapp')}>Contact by WhatsApp</button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}

// Seller verification component
function SellerVerification({ seller }) {
  const [verified, setVerified] = useState(null);

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      const result = await (async () => {
        try {
          const res = await fetch('http://localhost:5000/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ seller })
          });
          const data = await res.json();
          return data.verified;
        } catch {
          return false;
        }
      })();
      if (mounted) setVerified(result);
    })();
    return () => { mounted = false; };
  }, [seller]);

  if (verified === null) return <span>Verifying seller...</span>;
  return verified ? <span style={{color:'green'}}>✔ Verified Seller</span> : <span style={{color:'red'}}>✖ Not Verified</span>;
}

// Login form
function LoginForm({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  return (
    <form onSubmit={e => { e.preventDefault(); onLogin(email, password); }}>
      <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
      <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required />
      <button type="submit">Login</button>
    </form>
  );
}

// Register form
function RegisterForm({ onRegister }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  return (
    <form onSubmit={e => { e.preventDefault(); onRegister(name, email, password); }}>
      <input type="text" placeholder="Name" value={name} onChange={e => setName(e.target.value)} required />
      <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
      <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required />
      <button type="submit">Register</button>
    </form>
  );
}

export default App;
