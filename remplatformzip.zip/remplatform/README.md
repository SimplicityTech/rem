# REM (Real Estate Market) Platform

## Project Overview
REM is an AI-powered platform connecting buyers and sellers in the real estate industry. Buyers create wishlists of property features and ideal locations. The platform uses AI to search for matching properties online, verifies sellers, and automates contact via email/WhatsApp. Security and user protection are prioritized.

## Tech Stack
- Frontend: React
- Backend: Node.js/Express
- AI/ML Microservice: Python
- Database: PostgreSQL
- Security: OAuth2, HTTPS, input validation, anti-fraud

## Features
- Buyer registration & wishlist creation
- AI property matching (95%+ match, location scoring)
- Seller verification
- Automated contact (email/WhatsApp)
- Admin dashboard
- Cybersecurity protections

## Deployment
- Domain: homemarket.africa

## Next Steps
1. Scaffold frontend, backend, AI microservice, and database
2. Implement core features
3. Integrate security and verification
4. Prepare for deployment

---
This README will be updated as development progresses.