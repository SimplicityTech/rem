-- database/schema.sql
-- PostgreSQL schema for REM platform

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password_hash VARCHAR(255),
    role VARCHAR(20) -- buyer, seller, admin
);

CREATE TABLE wishlists (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    features JSONB,
    ideal_location VARCHAR(255)
);

CREATE TABLE properties (
    id SERIAL PRIMARY KEY,
    seller_id INTEGER REFERENCES users(id),
    features JSONB,
    location VARCHAR(255),
    verified BOOLEAN DEFAULT FALSE
);

CREATE TABLE contacts (
    id SERIAL PRIMARY KEY,
    buyer_id INTEGER REFERENCES users(id),
    property_id INTEGER REFERENCES properties(id),
    contact_method VARCHAR(20), -- email, whatsapp
    status VARCHAR(20)
);
